<footer class="footer-area">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-12">
                <p>Copyright © 2022 Belmont Doors Ltd. All Rights Reserved. </p>
            </div>
            <div class="col-md-6 col-sm-12">
                <a target="_blank" href="https://belmontdoors.ca/ordering-options">Contact Us</a>
                <span>Tel.: 905.282.1722 </span>
                <div class="payment_logo">

                    <a target="_blank" href="https://www.authorize.net/"><img class="payment_logo_one"
                            src="img/authorize.jpg" alt=""></a>
                    <img class="payment_logo_two" src="img/visa-mastercard-amex.png" alt="">
                </div>
            </div>
        </div>
    </div>
</footer>
