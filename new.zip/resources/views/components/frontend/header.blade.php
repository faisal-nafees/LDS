  <!-- Start: Header Section
==================================================-->
  <div class="header-top">
      <!-- Logo -->
      <div class="container">
          <div class="row">
              <div class="col-sm-12">
                  <div class="header-top-text">
                      Welcome to Belmont Doors' MDF Cabinet Doors and Premium Dovetail Drawers Store Online | All Prices in $CA
                  </div>
                  <div class="header-social">
                      <ul>
                          <li>
                              <a href="#">
                                  <img src="img/facebook.png" alt=""></a>
                          </li>
                          <li>
                              <a href="#">
                                  <img src="img/linkedin.png" alt=""></a>
                          </li>
                      </ul>
                  </div>
              </div>
              <!-- End: social-nav -->
          </div>
      </div>
  </div>
  <!-- End: Header Info -->
